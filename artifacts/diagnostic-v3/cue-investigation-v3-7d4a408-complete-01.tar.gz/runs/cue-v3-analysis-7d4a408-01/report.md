# Controlled diagnostic investigation

**EXPLORATORY LIVE RESULTS — NOT HELD-OUT CONFIRMATION.**

17 cases; 170 scheduled observations. All yields retain scheduled denominators; answered accuracy excludes abstentions and failures. Counts below are before verification; rejection is orthogonal.

| Think | Condition | N | Correct | Wrong | Abstain | Failure | Checker rejected | Released |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| False | no_diagnostic | 17 | 0 | 0 | 17 | 0 | 0 | 0 |
| False | correct_plain | 17 | 16 | 1 | 0 | 0 | 0 | 17 |
| False | wrong_plain | 17 | 0 | 17 | 0 | 0 | 0 | 17 |
| False | correct_qualified | 17 | 9 | 1 | 7 | 0 | 0 | 10 |
| False | wrong_qualified | 17 | 2 | 13 | 2 | 0 | 1 | 15 |
| True | no_diagnostic | 17 | 8 | 0 | 9 | 0 | 0 | 8 |
| True | correct_plain | 17 | 17 | 0 | 0 | 0 | 0 | 17 |
| True | wrong_plain | 17 | 6 | 11 | 0 | 0 | 0 | 17 |
| True | correct_qualified | 17 | 15 | 0 | 2 | 0 | 2 | 15 |
| True | wrong_qualified | 17 | 9 | 4 | 3 | 1 | 0 | 13 |

## Paired effects

Right minus left yield; intervals resample source families, retaining all conditions within a case. No automatic claim of significance or general causal reliability.
- Think=False, no_diagnostic → wrong_plain: wrong yield +100.0% [+100.0%, +100.0%]; correct yield +0.0% [+0.0%, +0.0%].
- Think=False, wrong_plain → correct_plain: wrong yield -94.1% [-100.0%, -83.3%]; correct yield +94.1% [+83.3%, +100.0%].
- Think=False, wrong_plain → wrong_qualified: wrong yield -23.5% [-50.0%, -5.0%]; correct yield +11.8% [+0.0%, +44.4%].
- Think=False, correct_plain → correct_qualified: wrong yield +0.0% [+0.0%, +0.0%]; correct yield -41.2% [-58.3%, -22.2%].
- Think=True, no_diagnostic → wrong_plain: wrong yield +64.7% [+47.6%, +90.9%]; correct yield -11.8% [-55.6%, +17.6%].
- Think=True, wrong_plain → correct_plain: wrong yield -64.7% [-90.9%, -47.6%]; correct yield +64.7% [+47.6%, +90.9%].
- Think=True, wrong_plain → wrong_qualified: wrong yield -41.2% [-70.0%, -28.6%]; correct yield +17.6% [+3.2%, +54.5%].
- Think=True, correct_plain → correct_qualified: wrong yield +0.0% [+0.0%, +0.0%]; correct yield -11.8% [-22.2%, +0.0%].

## Interpretation checklist

1. Does an incorrect cue increase wrong-answer yield relative to no diagnostic? Check paired transitions and failures.
2. Does the limitations statement reduce wrong copying through correct resistance or merely more abstention?
3. Does it also reduce correct answers when the cue is correct? Report the trade-off.
4. Compare thinking within this experiment only; repeated cells are not independent datasets.
5. Citation consistency does not establish causal correctness. Do not interpret explanations as proven internal mechanisms.

## Limitations

- Opened cohort; exploratory, one seed/model, seven source groups in full pilot.
- Controlled direction-only cues, not actual ANM scores or evidence of internal cognition.
- Schema/prompt differ from historical pilots; no direct historical accuracy comparison.
- Intervals are unadjusted exploratory source-group bootstraps, not confirmatory tests.
- Checker tests structured diagnostic attribution only; explanations and evidence_basis remain unverified.
