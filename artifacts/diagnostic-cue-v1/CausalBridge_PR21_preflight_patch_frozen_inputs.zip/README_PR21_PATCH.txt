CausalBridge PR #21 - PRE-LIVE REVIEW PATCH (2026-11-21)

This is a proposed patch for the DRAFT PR #21 branch, not a recorded live run.
Do not apply over main: check out experiment/counterfactual-anm-cue-v1-20261121 first.

Repository-relative paths in this archive:
  examples/diagnostic_counterfactual_probe.py
  tests/test_diagnostic_counterfactual_probe.py
  docs/experiments/diagnostic-counterfactual-study-v1.md
  sample_prepared/{public.jsonl,private-oracle.json,protocol.json}

Addresses:
1. Full server /api/tags digest validation before and after generation, plus locked decoding settings.
2. Independent pre-call requests.jsonl, raw response preservation, completion receipt, read-only audit-live CLI.
   analyze CLI refuses results without verified raw-response audit receipt.
3. No-card arm clearly described as anonymized observations with generic Measurement A/B labels.
4. SHA-locked 96-prompt frozen bytes prevent cross-platform float drift and accidental refreezing.

Commands (from repository root):
  python -m unittest discover -s tests -p 'test_diagnostic_counterfactual_probe.py' -v
  python examples/diagnostic_counterfactual_probe.py run-live --prepared sample_prepared --model-config configs/pilot-model.json --output runs/diagnostic-cue-v1-live
  python examples/diagnostic_counterfactual_probe.py audit-live --prepared sample_prepared --run runs/diagnostic-cue-v1-live --output runs/diagnostic-cue-v1-live/independent-audit.json
  python examples/diagnostic_counterfactual_probe.py analyze --prepared sample_prepared --responses runs/diagnostic-cue-v1-live/responses.jsonl --audit runs/diagnostic-cue-v1-live/independent-audit.json --output runs/diagnostic-cue-v1-live/analysis.json

Run-live requires a *live accessible Ollama endpoint* advertising the already-pinned exact digest.
No live inference was performed in this environment. All new test receipts are offline mock fixtures.
For true provenance, independently inspect saved raw model requests/responses; a JSON field alone is never authentication.
Do not merge, overwrite historical results, or call hypothetical cards fitted ANM results.
