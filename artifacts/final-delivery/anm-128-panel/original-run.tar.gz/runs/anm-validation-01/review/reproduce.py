"""Post-outcome descriptive review of cached ANM validation outputs; no fitting."""

import argparse
import json
import statistics
from pathlib import Path

from causalbridge.benchmark.validation.experiment import summarize
from causalbridge.benchmark.validation.synthetic import write_new


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    primary = json.loads((args.run / "analysis/dataset-results.json").read_text())
    allrows = json.loads((args.run / "analysis/all-evaluations.json").read_text())
    diagnostics = json.loads((args.run / "analysis/oracle-residual-diagnostics.json").read_text())
    subgroups = []
    for field in ["partition", "noise_distribution", "noise_scale", "ground_truth", "mechanism"]:
        comp = [r for r in primary if r["mechanism_class"] == "anm_compatible"]
        for value in sorted({str(r[field]) for r in comp}):
            rs = [r for r in comp if str(r[field]) == value]
            subgroups.append(dict(grouping=field, level=value, **summarize(rs)))
    for seed in [261, 1261]:
        rs = [
            r
            for r in allrows
            if r["mechanism_class"] == "anm_compatible"
            and r["orientation"] == "original"
            and r["split_seed"] == seed
        ]
        subgroups.append(dict(grouping="split_seed", level=str(seed), **summarize(rs)))
    write_new(args.output / "compatible-subgroups.json", subgroups)
    cases = []
    for d in diagnostics:
        r = next(
            r
            for r in allrows
            if r["dataset_id"] == d["dataset_id"]
            and r["split_seed"] == d["split_seed"]
            and r["orientation"] == "original"
        )
        reverse = r["score_ba"] if r["ground_truth"] == "A_to_B" else r["score_ab"]
        cases.append(
            d
            | dict(
                reverse_fitted_hsic=reverse,
                oracle_forward_preferred=d["oracle_noise_hsic"] < reverse,
            )
        )
    summaries = []
    for sign in [False, True]:
        rs = [r for r in cases if r["sign_correct"] == sign]
        summaries.append(
            dict(
                sign_correct=sign,
                split_outcomes=len(rs),
                unique_datasets=len({r["dataset_id"] for r in rs}),
                oracle_forward_preferred=sum(r["oracle_forward_preferred"] for r in rs),
                median_fitted_forward_hsic=statistics.median(r["fitted_forward_hsic"] for r in rs),
                median_oracle_noise_hsic=statistics.median(r["oracle_noise_hsic"] for r in rs),
                median_conditional_mean_mse=statistics.median(
                    r["conditional_mean_mse"] for r in rs
                ),
            )
        )
    write_new(
        args.output / "oracle-score-replacement.json",
        dict(
            exploratory_post_outcome=True,
            interpretation=(
                "True forward noise compared with unchanged reverse fitted residual; "
                "uses ground truth and is not an implementable estimator or tuned threshold."
            ),
            summary=summaries,
            cases=cases,
        ),
    )
    per_case = []
    for r in primary:
        per_case.append(
            dict(
                dataset_id=r["dataset_id"],
                family=r["family"],
                ground_truth=r["ground_truth"],
                scorable=r["scorable"],
                prediction=r["prediction"],
                correct=r["correct"],
                fit_wall_seconds=sum(t["fit_wall_seconds"] for t in r["directions"]),
                evaluation_wall_seconds=sum(t["evaluation_wall_seconds"] for t in r["directions"]),
                production_total_wall_seconds=r["production_wall_seconds"],
            )
        )
    write_new(args.output / "primary-timing.json", per_case)
    nonidentified = [r for r in primary if not r["scorable"]]
    write_new(
        args.output / "accounting.json",
        dict(
            primary_datasets=len(primary),
            all_answers=sum(r["prediction"] is not None for r in primary),
            nonidentified_n=len(nonidentified),
            nonidentified_answers=sum(r["prediction"] is not None for r in nonidentified),
            nonidentified_abstentions=sum(r["prediction"] is None for r in nonidentified),
            scorable_n=sum(r["scorable"] for r in primary),
            operational_abstentions=sum(r["prediction"] is None for r in primary),
            compatible_wrong_primary_ids=[
                r["dataset_id"]
                for r in primary
                if r["mechanism_class"] == "anm_compatible" and r["correct"] is False
            ],
        ),
    )
    print(json.dumps(dict(compatible_subgroups=subgroups, oracle_replacement=summaries), indent=2))


if __name__ == "__main__":
    main()
