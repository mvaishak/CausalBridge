# Cue investigation v2 plan freeze at Anish's commit

Branch: `codex/anm-evidence-investigation-20261121`, tracking the same named origin branch.
Source commit: `4f600b4c507bda66c0923a1a1a6546347a0b28f3`.
Protocol: `diagnostic-investigation-v2` with the single-decision output contract.
Live inference: none.

The former local prompt-only v2 commit `71ff36ae0dfc528b831b8206afb8103bb11bf01a` is preserved on local branch `codex/cue-v2-prompt-only-20261121`. No branch merge, force push, or v1 artifact change occurred. Earlier ignored v2 plans and archives were left intact; the paths below are new.

| Offline action | Result |
|---|---|
| `uv sync --frozen --dev --extra anm` | Exit 0; 22 packages audited |
| `uv run python -m pytest -q` | Exit 0; 1082 passed, 2 skipped for absent optional Tübingen snapshot |
| `uv run ruff check .` | Exit 0 |
| `uv run ruff format --check .` | Exit 0; 218 files formatted |
| `uv run python scripts/diagnostic_investigation.py smoke --protocol v2 --output runs/cue-v2-smoke-4f600b4-01` | Exit 0; 20 scripted preflight cells, 170 scripted full cells, zero live calls |
| `uv run python scripts/diagnostic_investigation.py prepare --protocol v2 --phase preflight --output runs/cue-v2-preflight-plan-4f600b4-01` | Exit 0; 20 frozen requests, 2 synthetic cases |
| `uv run python scripts/diagnostic_investigation.py prepare --protocol v2 --phase full --output runs/cue-v2-full-plan-4f600b4-01` | Exit 0; 170 frozen requests, 17 opened pilot cases |
| `validate_plan` on both new plans | Passed; manifests record exact source commit above |
| Independent v1/v2 plan comparison | Same ordered user messages, generation options, thinking settings, and evaluator fields except trial IDs; all v2 trial IDs unique |

The v2 system message and response schema intentionally differ from v1. V2 derives internal direction and abstention from one model-generated `decision` enum; it does not reinterpret saved v1 failures. The v2 live preflight has not been run and cannot be inferred from scripted smoke.

Before any later full run, compare the live preflight's ordered requests with the independently frozen v2 preflight plan. The inherited full-run gate does not reconstruct those 20 expected requests from a separate plan, and `validate_plan` does not enforce seeded order against a jointly reordered, rehashed plan. The new plans were independently checked for the expected order and unique cells.
