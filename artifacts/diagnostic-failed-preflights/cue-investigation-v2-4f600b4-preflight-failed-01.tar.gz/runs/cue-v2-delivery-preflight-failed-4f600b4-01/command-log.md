# V2 live execution command log

Source commit: `4f600b4c507bda66c0923a1a1a6546347a0b28f3`.

Previously completed at this commit: frozen dependency sync, full pytest suite (1082 passed, 2 optional-data skips), ruff lint and format checks, scripted 20/170-cell smoke, and preparation/validation of new 20/170-cell plans. See `runs/cue-v2-plan-delivery-4f600b4-01/command-log.md` for the offline record.

In this live attempt, `/api/version`, `/api/tags`, and `/api/ps` were read first. The model was unloaded, so the endpoint received one empty `/api/generate` preload request for `qwen3:8b`; it returned `done_reason: load` and an empty response, with no trial or generated answer. `/api/ps` then showed the pinned model fully in VRAM. The ordered frozen preflight and full requests were compared byte-for-byte with the independently generated scripted plans.

The only live trial command was:

```sh
UV_CACHE_DIR=/private/tmp/cue-uv-cache uv run python scripts/diagnostic_investigation.py run --plan runs/cue-v2-preflight-plan-4f600b4-01 --output runs/cue-v2-preflight-live-4f600b4-01 --base-url http://127.0.0.1:11435
```

It exited 1 after saving the first raw reply and failure record. The v2 fail-fast runner wrote `summary.json` and both model snapshots. No `--resume` was used because the failure was saved and the run completed its failure summary. No full-run command, additional live trial, model/config/protocol edit, retry, branch merge, or final-report rewrite occurred.
