# V2 live preflight: failed after first cell

**Verdict:** `preflight_passed: false`. The 170-cell full experiment was not started. This is a synthetic software preflight, not a scientific outcome on the 17 pilot pairs.

## Identity and infrastructure

- Branch: `codex/anm-evidence-investigation-20261121`; commit: `4f600b4c507bda66c0923a1a1a6546347a0b28f3`.
- Frozen protocol: `diagnostic-investigation-v2`, single-decision output contract.
- Endpoint: `http://127.0.0.1:11435`, Ollama 0.40.17.
- Pinned model: `qwen3:8b`, digest `500a1f067a9f782620b40bee6f7b0c89e17ae61f686b92c24933e4ca4b2b8b41` in `/api/tags` and both run snapshots.
- Before inference, an empty Ollama preload response had `done_reason: load` and no generated answer. `/api/ps` reported the entire 9,986,438,594-byte loaded model in VRAM. After the first frozen trial, the saved model snapshot reported `size_vram: 6312228290` of `size: 6312228290`, `context_length: 8192`, runner `llamacpp`.

## Frozen request and observed response

Both frozen plans passed `validate_plan`. Their 20 and 170 ordered requests and evaluator rows matched the independently generated scripted plans exactly, with unique trial IDs. The live run's saved request list equals the 20-cell frozen preflight request list.

The first scheduled trial was `PREFLIGHT_0`, `no_diagnostic`, thinking on, with no supplied cue. Trial ID: `sha256:900417757738ec91efa5d93e130488205295f0aaed7aca7974d35f91c0534643`. The record's request digest matched the frozen payload. Its raw digest, `sha256:84dee6d653ad9ef80de2b5bbb728cb193d0bde17bc8d2729067e23a9699c1fe7`, matched the saved raw file.

Ollama returned HTTP 200, the expected model, `done: true`, `done_reason: stop`, and nonempty thinking; no truncation or transport error was recorded. The exact final JSON included:

```json
{"decision":"abstain","diagnostic_direction_cited":null,"evidence_basis":["variable_names","measurements","variable_names","measurements"],"explanation":"The data shows a positive correlation between A and B, but without external diagnostic cues or temporal precedence, causation cannot be determined. Both A→B and B→A are plausible without additional evidence."}
```

The model generated duplicate `evidence_basis` values. V2's supplied schema declares uniqueness and the unchanged application validator also rejects duplicates. Replaying `diagnostic_runtime.decode` on the saved raw response reproduced the recorded `CueDecisionV2` validation failure: `duplicate evidence bases`. No parser repair or retry was performed.

## Acceptance accounting

| Measure | Count |
|---|---:|
| Scheduled synthetic preflight cells | 20 |
| Completed live cells | 1 |
| Saved raw responses | 1 |
| Execution failures, specifically schema/validation | 1 |
| Checker rejections | 0 |
| Transport failures | 0 |
| Valid abstentions | 0 |
| Unsent cells after v2 fail-fast stop | 19 |

The raw `decision: abstain` is not counted as a valid abstention because the complete structured response failed validation. The frozen gate requires all 20 cells completed, zero failures, and zero checker rejections. Its summary correctly reports `completed: 1`, `scheduled: 20`, `failures: 1`, `verification_rejections: 0`, and `preflight_passed: false`. There are no paired effects, source-group intervals, coverage trade-offs, or diagnostic-following findings from this failed synthetic preflight. The full-run offline analyzer cannot score an unexecuted 170-cell run.
