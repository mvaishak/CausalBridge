# Fresh preflight repeat stopped on the same schema failure

Code commit: b8b5b44367ae18f3d666b4cb9d33ec6c7ba0ba77
Branch: codex/anm-evidence-investigation-20261121
Protocol: diagnostic-investigation-v1
Endpoint: http://127.0.0.1:11435

The four preceding live preflight directories were removed at the user's request after verifying that every file was present in `cue-investigation-preflight-schema-failed-04.tar.gz` and that its SHA-256 manifest passed. The prior archives remain in the worktree.

Fresh commands:

| Command | Result |
|---|---|
| `UV_CACHE_DIR=/private/tmp/cue-uv-cache uv sync --frozen --dev --extra anm` | exit 0; 22 packages audited |
| `UV_CACHE_DIR=/private/tmp/cue-uv-cache uv run python -m pytest tests/test_diagnostic_investigation.py -q` | exit 0; 26 passed |
| `UV_CACHE_DIR=/private/tmp/cue-uv-cache uv run python scripts/diagnostic_investigation.py diagnose --output runs/cue-diagnosis-02` | exit 0 |
| `UV_CACHE_DIR=/private/tmp/cue-uv-cache uv run python scripts/diagnostic_investigation.py smoke --output runs/cue-smoke-02` | exit 0; 20 scripted preflight and 170 scripted full cells; zero live calls |
| `UV_CACHE_DIR=/private/tmp/cue-uv-cache uv run python scripts/diagnostic_investigation.py prepare --phase preflight --output runs/cue-preflight-plan-02` | exit 0; 20 frozen requests |
| `UV_CACHE_DIR=/private/tmp/cue-uv-cache uv run python scripts/diagnostic_investigation.py prepare --phase full --output runs/cue-full-plan-02` | exit 0; 170 frozen requests |
| `UV_CACHE_DIR=/private/tmp/cue-uv-cache uv run python scripts/diagnostic_investigation.py run --plan runs/cue-preflight-plan-02 --output runs/cue-preflight-live-05 --base-url http://127.0.0.1:11435` | interrupted with SIGINT after the first saved schema failure; exit 130 |

Before the live run, `/api/version` reported Ollama 0.40.17 and `/api/tags` reported the pinned `qwen3:8b` digest `500a1f067a9f782620b40bee6f7b0c89e17ae61f686b92c24933e4ca4b2b8b41`. The new plan manifests equal the old manifests. No config, prompt, schema, budget, condition, or model was changed.

The first scheduled response returned HTTP 200, model `qwen3:8b`, `done_reason: stop`, and nonempty thinking. Its content again had `predicted_direction: B_to_A` together with `abstained: true`, which violates the frozen `CuePrediction` schema's null-direction abstention rule. The saved record has raw digest `sha256:e986871a9f1d7f1891838ca2c66a9240420d53987b88d90ea819be1af5c44ce8`. This reproduces the earlier failure in the same first cell and with the same final prediction content. The raw response differs in its complete bytes from the earlier response.

The runner had begun the next request when interrupted. It has no saved raw response or record, and remote computation may have begun. This repeat has one saved live response and one saved failure, no passing 20-call preflight, no full run, and no live outcome analysis. The experiment's paired effects, source-group intervals, and coverage trade-offs are unavailable.
